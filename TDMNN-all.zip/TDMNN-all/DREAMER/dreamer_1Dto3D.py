import time
from sklearn import preprocessing
from scipy.signal import butter, lfilter
import scipy.io as sio
import numpy as np
import os
import math
import sys


def read_file(file):
    file = sio.loadmat(file)
    trial_data = file['data']
    base_data = file["base_data"]
    return trial_data, base_data, file["arousal_labels"], file["valence_labels"]


def get_vector_deviation(vector1, vector2):
    return vector1 - vector2


def get_dataset_deviation(trial_data, base_data):
    new_dataset = np.empty([0, 56])
    for i in range(0, 7456):
        if 0 <= i < 398:
            base_index = 0
        elif 398 <= i < 660:
            base_index = 1
        elif 660 <= i < 1356:
            base_index = 2
        elif 1356 <= i < 1688:
            base_index = 3
        elif 1688 <= i < 1960:
            base_index = 4
        elif 1960 <= i < 2340:
            base_index = 5
        elif 2340 <= i < 2724:
            base_index = 6
        elif 2724 <= i < 3512:
            base_index = 7
        elif 3512 <= i < 3802:
            base_index = 8
        elif 3802 <= i < 3936:
            base_index = 9
        elif 3936 <= i < 4128:
            base_index = 10
        elif 4128 <= i < 4490:
            base_index = 11
        elif 4490 <= i < 5226:
            base_index = 12
        elif 5226 <= i < 5566:
            base_index = 13
        elif 5566 <= i < 6182:
            base_index = 14
        elif 6182 <= i < 6572:
            base_index = 15
        elif 6572 <= i < 7084:
            base_index = 16
        elif 7084 <= i < 7456:
            base_index = 17          
        # print(base_index)

        new_record = get_vector_deviation(trial_data[i], base_data[base_index]).reshape(1, 56)
        # print(new_record.shape)
        new_dataset = np.vstack([new_dataset, new_record])
    # print("new shape:",new_dataset.shape)
    return new_dataset


def data_1Dto2D(data, Y=8, X=9):
    data_2D = np.zeros([Y, X])
    data_2D[0] = (0, 0, data[0], 0, 0, 0, data[13], 0, 0)  #4
    data_2D[1] = (0, data[1], 0, data[2], 0, data[11], 0, data[12], 0)  #5
    data_2D[2] = (0, 0, data[3], 0, 0, 0, data[10], 0, 0)   #4
    data_2D[3] = (0, data[4], 0, 0, 0, 0, 0, data[9], 0)   #5
    data_2D[4] = (0, 0, 0, 0, 0, 0, 0, 0, 0)     #4
    data_2D[5] = (0, data[5], 0, 0, 0, 0, 0, data[8],0)   #5
    data_2D[6] = (0, 0, 0, 0, 0, 0, 0, 0, 0)   #2
    data_2D[7] = (0, 0, 0, data[6], 0, data[7], 0, 0, 0)   #3
    # return shape:9*9
    return data_2D


def pre_process(path, y_n):
    # DE feature vector dimension of each band
    data_3D = np.empty([0, 8, 9])
    sub_vector_len = 14
    trial_data, base_data, arousal_labels, valence_labels = read_file(path)
    if y_n == "yes":
        data = get_dataset_deviation(trial_data, base_data)
        data = preprocessing.scale(data, axis=1, with_mean=True, with_std=True, copy=True)
    else:
        data = preprocessing.scale(trial_data, axis=1, with_mean=True, with_std=True, copy=True)
    # convert 128 vector ---> 4*9*9 cube
    for vector in data:
        for band in range(0, 4):
            data_2D_temp = data_1Dto2D(vector[band * sub_vector_len:(band + 1) * sub_vector_len])
            data_2D_temp = data_2D_temp.reshape(1, 8, 9)
            # print("data_2d_temp shape:",data_2D_temp.shape)
            data_3D = np.vstack([data_3D, data_2D_temp])
    data_3D = data_3D.reshape(-1, 4, 8, 9)
    print("final data shape:", data_3D.shape)
    return data_3D, arousal_labels, valence_labels


if __name__ == '__main__':
    dataset_dir = "G:\\4情绪识别任务2\\4D-CRNN-master(4区)调整\\dreamer数据集\\all_0.5\\"
    use_baseline = "yes"
    if use_baseline == "yes":
        result_dir = "G:\\4情绪识别任务2\\4D-CRNN-master(4区)调整\\dreamer数据集\\with_base_0.5\\"
        if os.path.isdir(result_dir) == False:
            os.makedirs(result_dir)
    else:
        result_dir = "G:\\4情绪识别任务2\\4D-CRNN-master(4区)调整\\dreamer数据集\\without_base_0.5\\"
        if os.path.isdir(result_dir) == False:
            os.makedirs(result_dir)

    for file in os.listdir(dataset_dir):
        print("processing: ", file, "......")
        file_path = os.path.join(dataset_dir, file)
        data, arousal_labels, valence_labels = pre_process(file_path, use_baseline)
        print("final shape:", data.shape)
        sio.savemat(result_dir + file,
                    {"data": data, "valence_labels": valence_labels, "arousal_labels": arousal_labels})
        # break