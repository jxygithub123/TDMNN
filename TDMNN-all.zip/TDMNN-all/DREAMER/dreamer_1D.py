import os
import sys
import math
import numpy as np
import pandas as pd
import scipy.io as sio
from sklearn import preprocessing
from scipy.signal import butter, lfilter


def butter_bandpass(lowcut, highcut, fs, order=5):
    nyq = 0.5 * fs
    low = lowcut / nyq
    high = highcut / nyq
    b, a = butter(order, [low, high], btype='band')
    return b, a


def butter_bandpass_filter(data, lowcut, highcut, fs, order=5):
    b, a = butter_bandpass(lowcut, highcut, fs, order=order)
    y = lfilter(b, a, data)
    return y


def read_file(file):
    data = sio.loadmat(file)
    data = data['data']
    # print(data.shape)
    return data


def compute_DE(signal):
    variance = np.var(signal, ddof=1)
    return math.log(2 * math.pi * math.e * variance) / 2


def decompose(file1, file2):
    # trial*channel*sample

    
    data1 = file1
    data2 = file2
    frequency = 128


#---------------------------------计算base_signal-----------------------------------------#
    base_DE = np.empty([0, 56])
    for trial in range(18):
        temp_base_DE = np.empty([0])
        temp_base_theta_DE = np.zeros(shape=[0], dtype=float)
        temp_base_alpha_DE = np.zeros(shape=[0], dtype=float)
        temp_base_beta_DE = np.zeros(shape=[0], dtype=float)
        temp_base_gamma_DE = np.zeros(shape=[0], dtype=float)

        for channel in range(14):

            base_signal = data1[trial][0][:,channel]
            # ****************compute base DE****************
            base_theta = butter_bandpass_filter(base_signal, 4, 8, frequency, order=3)
            base_alpha = butter_bandpass_filter(base_signal, 8, 14, frequency, order=3)
            base_beta = butter_bandpass_filter(base_signal, 14, 31, frequency, order=3)
            base_gamma = butter_bandpass_filter(base_signal, 31, 45, frequency, order=3)
            base_theta_DE=0
            base_alpha_DE=0
            base_beta_DE=0
            base_gamma_DE=0
            for dd in range(122):
                base_theta_DE = base_theta_DE+compute_DE(base_theta[64*(dd):64*(dd+1)])
                base_alpha_DE = base_alpha_DE+compute_DE(base_alpha[64*(dd):64*(dd+1)])
                base_beta_DE =  base_beta_DE +compute_DE(base_beta[64*(dd):64*(dd+1)])
                base_gamma_DE = base_gamma_DE+compute_DE(base_gamma[64*(dd):64*(dd+1)])
                
            base_theta_DE=base_theta_DE/122
            base_alpha_DE=base_alpha_DE/122
            base_beta_DE =base_beta_DE /122
            base_gamma_DE=base_gamma_DE/122

            temp_base_theta_DE = np.append(temp_base_theta_DE, base_theta_DE)
            temp_base_gamma_DE = np.append(temp_base_gamma_DE, base_gamma_DE)
            temp_base_beta_DE = np.append(temp_base_beta_DE, base_beta_DE)
            temp_base_alpha_DE = np.append(temp_base_alpha_DE, base_alpha_DE)

        temp_base_DE = np.append(temp_base_theta_DE, temp_base_alpha_DE)
        temp_base_DE = np.append(temp_base_DE, temp_base_beta_DE)
        temp_base_DE = np.append(temp_base_DE, temp_base_gamma_DE)
        base_DE = np.vstack([base_DE, temp_base_DE])    
    
    

#---------------------------------计算simulate_signal-----------------------------------------#    
    all_DE=[]  
    for channel in range(14): 
        temp_de_theta = np.empty([0])
        temp_de_alpha= np.empty([0])
        temp_de_beta= np.empty([0])
        temp_de_gamma= np.empty([0])
        for trial in range(18):
            
            shape=data2[trial][0].shape[0]
            shape=shape/64
            trial_signal = data2[trial][0][:,channel]    #次数 [0] 数据 通道数
            theta = butter_bandpass_filter(trial_signal, 4, 8, frequency, order=3)
            alpha = butter_bandpass_filter(trial_signal, 8, 14, frequency, order=3)
            beta = butter_bandpass_filter(trial_signal, 14, 31, frequency, order=3)
            gamma = butter_bandpass_filter(trial_signal, 31, 45, frequency, order=3)

            DE_theta = np.zeros(shape=[0], dtype=float)
            DE_alpha = np.zeros(shape=[0], dtype=float)
            DE_beta = np.zeros(shape=[0], dtype=float)
            DE_gamma = np.zeros(shape=[0], dtype=float)

            for index in range(int(shape)):                               #60s,一段0.5s，共120
                DE_theta = np.append(DE_theta, compute_DE(theta[index * 64:(index + 1) * 64]))
                DE_alpha = np.append(DE_alpha, compute_DE(alpha[index * 64:(index + 1) * 64]))
                DE_beta = np.append(DE_beta, compute_DE(beta[index * 64:(index + 1) * 64]))
                DE_gamma = np.append(DE_gamma, compute_DE(gamma[index * 64:(index + 1) * 64]))
            temp_de_theta = np.append(temp_de_theta, DE_theta)
            temp_de_alpha = np.append(temp_de_alpha, DE_alpha)
            temp_de_beta = np.append(temp_de_beta, DE_beta)
            temp_de_gamma = np.append(temp_de_gamma, DE_gamma)
        decomposed_de = np.vstack([temp_de_theta, temp_de_alpha, temp_de_beta, temp_de_gamma])
        all_DE.append(decomposed_de)
    combined_matrix = np.stack(all_DE, axis=2)
    all_de = combined_matrix.transpose([1, 2, 0]).reshape(-1, 56)

        # temp_base_DE = np.append(temp_base_theta_DE, temp_base_alpha_DE)
        # temp_base_DE = np.append(temp_base_DE, temp_base_beta_DE)
        # temp_base_DE = np.append(temp_base_DE, temp_base_gamma_DE)
        
        # base_DE = np.vstack([base_DE, temp_base_DE])
    
    print("base_DE shape:", base_DE.shape)
    print("trial_DE shape:",all_de.shape)
    return base_DE, all_de


def get_labels(file):
    # 0 valence, 1 arousal, 2 dominance, 3 liking
    valence_labels = file[4] > 3  # valence labels
    arousal_labels = file[5] > 3  # arousal labels
    final_valence_labels = np.empty([0])
    final_arousal_labels = np.empty([0])
    
    num=[398, 262, 696, 332, 272, 380, 384, 788, 290, 134, 192, 362, 736, 340, 616, 390, 512, 372]
    for i in range(len(valence_labels)):    #18
        for j in range(0, num[i]):
            final_valence_labels = np.append(final_valence_labels, valence_labels[i])
            final_arousal_labels = np.append(final_arousal_labels, arousal_labels[i])
    print("labels:", final_arousal_labels.shape)
    return final_arousal_labels, final_valence_labels


def wgn(x, snr):
    snr = 10 ** (snr / 10.0)
    xpower = np.sum(x ** 2) / len(x)
    npower = xpower / snr
    return np.random.randn(len(x)) * np.sqrt(npower)


def feature_normalize(data):
    mean = data[data.nonzero()].mean()
    sigma = data[data.nonzero()].std()
    data_normalized = data
    data_normalized[data_normalized.nonzero()] = (data_normalized[data_normalized.nonzero()] - mean) / sigma
    return data_normalized


if __name__ == '__main__':
    from scipy.io import loadmat

    # 读取.mat文件
    mat_data = loadmat('G:\\4情绪识别任务2\\4D-CRNN-master(4区)调整\\dreamer数据集\\DREAMER.mat')
    
    struct_data = mat_data['DREAMER'][0][0]
    
    eeg_data = struct_data[0]
    
    for i in range(23):
        variable_name1 = 'dreamer_eeg_base' + str(i)
        globals()[variable_name1] = eeg_data[0][i][0][0][2][0][0][0]
    for i in range(23):
        variable_name2 = 'dreamer_eeg_stimuli' + str(i)
        globals()[variable_name2] = eeg_data[0][i][0][0][2][0][0][1]
    for i in range(23):
        variable_name3 = 'dreamer_eeg_label' + str(i)
        globals()[variable_name3] = eeg_data[0][i][0][0]

        
        
    result_dir = "G:\\4情绪识别任务2\\4D-CRNN-master(4区)调整\\dreamer数据集\\all_0.5\\"
    
    if os.path.isdir(result_dir) == False:
        os.makedirs(result_dir)

    for k in range(23):
        print("processing: s", k, "......")
        file1 = 'dreamer_eeg_base' + str(k)
        file2 = 'dreamer_eeg_stimuli' + str(k)
        file3 = 'dreamer_eeg_label' + str(k)
        
        base_DE, trial_DE = decompose(globals()[file1],globals()[file2])

        arousal_labels, valence_labels = get_labels(globals()[file3])
        sio.savemat(result_dir + "DE_num" + str(k)+".mat",
                    {"base_data": base_DE, "data": trial_DE, "valence_labels": valence_labels,
                     "arousal_labels": arousal_labels})
